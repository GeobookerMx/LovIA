import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import {
    ArrowLeft, MapPin, Clock, Coffee, MessageCircle,
    Shield, Check, AlertTriangle, Phone, Loader2
} from 'lucide-react'
import { supabase } from '../../lib/supabase'
import './Matching.css'

const defaultPlan = {
    place_type: 'Buscando punto medio...',
    why: 'Calculando distancia equitativa',
    suggested_duration: '60-90 minutos',
    exit_protocol: 'Puedes salir cuando quieras sin dar explicaciones. Un simple "fue un gusto" es suficiente.',
    starters: [
        '¿Qué te motivó a probar LovIA!?',
        '¿Cuál fue tu momento más feliz esta semana?',
        '¿Qué es lo primero que notas de un lugar?',
        'Si pudieras cenar con cualquier persona, ¿quién sería?',
        '¿Cuál es tu gusto culposo?',
    ],
}

const safetyItems = [
    { id: 'public', label: 'El lugar es público y concurrido', icon: <MapPin size={16} /> },
    { id: 'contact', label: 'Compartí ubicación con mi contacto de confianza', icon: <Phone size={16} /> },
    { id: 'charged', label: 'Celular cargado al 100%', icon: <Shield size={16} /> },
    { id: 'transport', label: 'Tengo transporte propio de regreso', icon: <Clock size={16} /> },
    { id: 'exit', label: 'Leí el protocolo de salida segura', icon: <AlertTriangle size={16} /> },
]

export default function MeetingPlan() {
    const { id } = useParams<{ id: string }>()
    const navigate = useNavigate()
    const [checkedItems, setCheckedItems] = useState<Set<string>>(new Set())
    const [venueInfo, setVenueInfo] = useState<any>(null)
    const [loadingVenue, setLoadingVenue] = useState(true)
    const [sosActive, setSosActive] = useState(false)

    const handleSOS = async () => {
        setSosActive(true)
        // Here we simulate fetching the user's emergency contacts from private_profiles
        // and dispatching an SMS via an Edge Function (e.g. Twilio)
        setTimeout(() => {
            alert('🚨 ALERTA SOS ENVIADA 🚨\n\nSe ha compartido tu ubicación en tiempo real y detalles del encuentro con tus Contactos de Emergencia (MVP 3.5).')
            setSosActive(false)
        }, 1500)
    }

    useEffect(() => {
        async function fetchVenue() {
            if (!id) return
            const { data, error } = await supabase.rpc('suggest_safe_venue', { p_match_id: id })
            if (error || !data) {
                console.error("Error fetching safe venue:", error)
            } else {
                setVenueInfo(data)
            }
            setLoadingVenue(false)
        }
        fetchVenue()
    }, [id])

    const toggleCheck = (itemId: string) => {
        setCheckedItems((prev) => {
            const next = new Set(prev)
            if (next.has(itemId)) next.delete(itemId)
            else next.add(itemId)
            return next
        })
    }

    const allChecked = checkedItems.size === safetyItems.length
    const mergedPlan = { ...defaultPlan, ...venueInfo }

    return (
        <div className="meeting-plan">
            {/* Header */}
            <div className="meeting-plan__header">
                <button className="meeting-plan__back" onClick={() => navigate(`/matches/${id}`)}>
                    <ArrowLeft size={20} />
                </button>
                <h2>Plan de Encuentro</h2>
            </div>

            {/* Place suggestion */}
            <div className="meeting-plan__card glass-strong animate-fade-in-up" style={{ position: 'relative', overflow: 'hidden' }}>
                <div style={{ position: 'absolute', top: 0, right: 0, background: 'var(--success)', color: 'white', fontSize: '10px', padding: '4px 12px', fontWeight: 'bold', borderBottomLeftRadius: '8px' }}>
                    PATROCINADOR OFICIAL
                </div>
                <h3 style={{ marginTop: '8px' }}><Coffee size={18} /> Partner Geobooker Seguros</h3>
                {loadingVenue ? (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--text-secondary)' }}>
                        <Loader2 size={16} className="animate-spin"/> Calculando punto medio seguro...
                    </div>
                ) : (
                    <div className="meeting-plan__detail">
                        <div className="meeting-plan__detail-row" style={{ color: 'var(--love-rose)' }}>
                            <MapPin size={18} /> <strong>{mergedPlan.place_type}</strong>
                        </div>
                        <p style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-tertiary)' }}>
                            {mergedPlan.why}
                        </p>
                        {mergedPlan.safety_rating && (
                            <div style={{ marginTop: '8px', fontSize: 'var(--fs-xs)', color: 'var(--success)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                                <Shield size={12}/> Rating Seguridad Geobooker: {mergedPlan.safety_rating}/5
                            </div>
                        )}
                        <div className="meeting-plan__detail-row" style={{ marginTop: '12px' }}>
                            <Clock size={14} /> Duración recomendada: {mergedPlan.suggested_duration}
                        </div>
                    </div>
                )}
            </div>

            {/* Safety checklist */}
            <div className="meeting-plan__card glass-strong animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
                <h3><Shield size={18} /> Checklist de Seguridad</h3>
                <div className="meeting-plan__checklist">
                    {safetyItems.map((item) => (
                        <div
                            key={item.id}
                            className={`meeting-plan__check-item ${checkedItems.has(item.id) ? 'meeting-plan__check-item--done' : ''
                                }`}
                            onClick={() => toggleCheck(item.id)}
                        >
                            <div className="meeting-plan__check-box">
                                {checkedItems.has(item.id) && <Check size={14} />}
                            </div>
                            {item.icon}
                            <span>{item.label}</span>
                        </div>
                    ))}
                </div>
            </div>

            {/* Conversation starters */}
            <div className="meeting-plan__card glass-strong animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
                <h3><MessageCircle size={18} /> Tips de Conversación</h3>
                <div className="meeting-plan__starters">
                    {mergedPlan.starters.map((s: string, i: number) => (
                        <div key={i} className="meeting-plan__starter">
                            {s}
                        </div>
                    ))}
                </div>
            </div>

            {/* Exit protocol */}
            <div className="meeting-plan__card glass animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
                <h3><AlertTriangle size={18} /> Protocolo de Salida</h3>
                <p style={{ fontSize: 'var(--fs-sm)', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
                    {mergedPlan.exit_protocol}
                </p>
            </div>

            {/* SOS button */}
            <button 
                className="meeting-plan__sos" 
                onClick={handleSOS}
                disabled={sosActive}
                style={{ opacity: sosActive ? 0.7 : 1 }}
            >
                {sosActive ? <Loader2 size={18} className="animate-spin" /> : '🆘 Botón SOS — Compartir ubicación'}
            </button>

            {/* Proceed */}
            {allChecked && (
                <button
                    className="match-detail__accept animate-fade-in-up"
                    onClick={() => navigate(`/matches/${id}`)}
                >
                    <Check size={16} /> Todo listo — ¡A conocerse!
                </button>
            )}
        </div>
    )
}
