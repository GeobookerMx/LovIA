import { useState, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft, ArrowRight, Sparkles } from 'lucide-react'
import { momentoDeVidaQuestions, vinculoQuestions } from './questionData'
import { calculateReadiness, type ReadinessResults } from './scoring'
import QuestionCard from './QuestionCard'
import './Onboarding.css'

import { useAuthStore } from '../../stores/authStore'
import { supabase } from '../../lib/supabase'

type Phase = 'welcome' | 'questions' | 'calculating' | 'result'

// Combinar ambos tests para el flujo
const allQuestions = [...momentoDeVidaQuestions, ...vinculoQuestions]

export default function OnboardingFlow() {
    const navigate = useNavigate()
    const { user, updateProfile } = useAuthStore()
    const [phase, setPhase] = useState<Phase>('welcome')
    const [qIndex, setQIndex] = useState(0)
    const [answers, setAnswers] = useState<Record<string, string | number>>({})
    const [result, setResult] = useState<ReadinessResults | null>(null)

    const totalSteps = allQuestions.length
    const currentStep = phase === 'questions' ? qIndex + 1 : 0
    const progress = totalSteps > 0 ? (currentStep / totalSteps) * 100 : 0

    // ── Question handlers ──
    const handleAnswer = useCallback((questionId: string, value: string | number) => {
        setAnswers((prev) => ({ ...prev, [questionId]: value }))
    }, [])

    const goNext = useCallback(() => {
        const q = allQuestions[qIndex]
        if (answers[q.id] === undefined) return

        if (qIndex < allQuestions.length - 1) {
            setQIndex((i) => i + 1)
        } else {
            setPhase('calculating')
            setTimeout(async () => {
                const res = calculateReadiness(answers)

                if (user) {
                    await supabase.from('assessments_raw').insert({
                        user_id: user.id,
                        test_type: 'momento_vida',
                        answers: answers
                    })

                    await supabase.from('assessment_scores').update({
                        readiness_score: res.readinessScore,
                        needs_support: res.needsSupport,
                        last_calculated_at: new Date().toISOString()
                    }).eq('id', user.id)
                }

                await updateProfile({ onboarding_completed: true })

                setResult(res)
                setPhase('result')
            }, 2500)
        }
    }, [qIndex, answers, updateProfile, user])

    const goBack = useCallback(() => {
        if (phase === 'questions' && qIndex > 0) {
            setQIndex((i) => i - 1)
        } 
    }, [phase, qIndex])

    // ── Welcome ──
    if (phase === 'welcome') {
        return (
            <div className="onboarding">
                <div className="onboarding__welcome animate-fade-in">
                    <div className="onboarding__welcome-icon animate-heartbeat">
                        <Sparkles size={48} color="var(--love-rose)" />
                    </div>
                    <h1>Tu Mapa de <span className="text-gradient">Momento de Vida</span></h1>
                    <p>
                        No buscamos enamorarte a la fuerza. Primero queremos entender
                        <strong> desde qué parte de ti te quieres vincular</strong>.
                    </p>
                    <ul className="onboarding__welcome-list">
                        <li>⏱️ ~3 minutos de honestidad pura</li>
                        <li>🔒 100% privado (no lo verán otros perfiles)</li>
                        <li>📚 Basado en el libro <strong>Evolución de las Relaciones de Pareja</strong> por J. P. Peña García</li>
                        <li>🪞 Respuestas reales logísticas y emocionales</li>
                    </ul>
                    <button className="onboarding__cta" onClick={() => setPhase('questions')}>
                        Comenzar Introspección <ArrowRight size={18} />
                    </button>
                </div>
            </div>
        )
    }

    // ── Calculating ──
    if (phase === 'calculating') {
        return (
            <div className="onboarding">
                <div className="onboarding__calculating">
                    <div className="onboarding__calc-orbs">
                        <div className="onboarding__orb onboarding__orb--love" />
                        <div className="onboarding__orb onboarding__orb--sex" />
                        <div className="onboarding__orb onboarding__orb--real" />
                    </div>
                    <h2 className="animate-pulse-soft">Analizando tu preparación...</h2>
                    <p>Calculando tu Readiness Score</p>
                </div>
            </div>
        )
    }

    // ── Result ──
    if (phase === 'result' && result) {
        return (
             <div className="onboarding">
                <div className="onboarding__welcome animate-fade-in">
                    <h1>Tu Perfil <span className="text-gradient">está Listo</span></h1>
                    <p>
                        {result.narrative}
                    </p>
                    <ul className="onboarding__welcome-list">
                        {result.recommendations.map((rec, i) => (
                            <li key={i}>💡 {rec}</li>
                        ))}
                    </ul>
                    
                    {!result.needsSupport ? (
                        <button className="onboarding__cta" onClick={() => navigate('/home')}>
                            Ir a Descubrimiento <ArrowRight size={18} />
                        </button>
                    ) : (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginTop: '2rem' }}>
                            <button className="onboarding__cta" onClick={() => navigate('/community')}>
                                Contactar Red de Apoyo Geobooker
                            </button>
                            <button className="onboarding__cta onboarding__cta--outline" onClick={() => navigate('/home')}>
                                Continuar a la app de todos modos
                            </button>
                        </div>
                    )}
                </div>
            </div>
        )
    }

    // ── Questions ──
    return (
        <div className="onboarding">
            {/* Progress bar */}
            <div className="onboarding__top-bar">
                <button
                    className="onboarding__back"
                    onClick={goBack}
                    disabled={qIndex === 0}
                >
                    <ArrowLeft size={20} />
                </button>
                <div className="onboarding__progress">
                    <div className="onboarding__progress-bar" style={{ width: `${progress}%` }} />
                </div>
                <span className="onboarding__step-count">{currentStep}/{totalSteps}</span>
            </div>

            {/* Card area */}
            <div className="onboarding__card-area">
                {phase === 'questions' && (
                    <>
                        <QuestionCard
                            key={allQuestions[qIndex].id}
                            question={allQuestions[qIndex]}
                            answer={answers[allQuestions[qIndex].id]}
                            onAnswer={(val: string | number) => handleAnswer(allQuestions[qIndex].id, val)}
                        />
                        <button
                            className="onboarding__next"
                            onClick={goNext}
                            disabled={answers[allQuestions[qIndex].id] === undefined}
                        >
                            {qIndex === allQuestions.length - 1 ? 'Terminar Evaluación' : 'Siguiente'}
                            <ArrowRight size={18} />
                        </button>
                    </>
                )}
            </div>
        </div>
    )
}
