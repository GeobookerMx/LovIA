import { momentoDeVidaQuestions, vinculoQuestions } from './questionData'

export interface OnboardingResults {
    frequency: number
    level: string
    levelEmoji: string
    lines: {
        label: string
        score: number
        color: string
        emoji: string
    }[]
    stressLevel: number
    stressLabel: string
    insights: string[]
}

export interface ReadinessResults {
    readinessScore: number
    needsSupport: boolean
    narrative: string
    recommendations: string[]
}

export function calculateReadiness(
    answers: Record<string, string | number>
): ReadinessResults {
    const allQuestions = [...momentoDeVidaQuestions, ...vinculoQuestions]
    
    let totalScore = 0
    let maxPossible = 0
    let hasCriticalRedFlag = false

    const factors: Record<string, number> = {}

    for (const q of allQuestions) {
        const ans = answers[q.id]
        if (ans === undefined) continue

        if (q.type === 'single' && q.options) {
            const opt = q.options.find((o) => o.id === ans)
            if (opt) {
                for (const [key, score] of Object.entries(opt.scores)) {
                    factors[key] = score
                    totalScore += score
                    maxPossible += 4 // Max for every question is 4
                    
                    // Critical red flags that trigger support
                    if ((key === 'readiness_status' && score === 0) || 
                        (key === 'attachment_anxiety' && score === 0) ||
                        (key === 'emotion_conflict' && score === 0)) {
                        hasCriticalRedFlag = true
                    }
                }
            }
        } else if (q.type === 'slider') {
            const normalized = ((ans as number) / 10) * 4
            for (const key of q.factorKeys) {
                factors[key] = normalized
                totalScore += normalized
                maxPossible += 4
            }
        }
    }

    const readinessScore = maxPossible > 0 ? Math.round((totalScore / maxPossible) * 100) : 0
    const needsSupport = readinessScore < 50 || hasCriticalRedFlag

    // Construct Narrative
    let narrative = ""
    const recommendations: string[] = []

    if (needsSupport) {
        narrative = "Parece que estás atravesando un momento de alta carga emocional o logística."
        recommendations.push("Considera tomarte un tiempo para ti antes de buscar una relación.")
        recommendations.push("Geobooker puede conectarte con especialistas si necesitas apoyo.")
    } else if (readinessScore < 75) {
        narrative = "Estás abierto/a a conectar, pero tienes límites logísticos o emocionales marcados."
        recommendations.push("Ve despacio. Comunica tus límites logísticos desde el principio.")
    } else {
        narrative = "Te encuentras en un excelente momento de disponibilidad y apertura emocional."
        recommendations.push("Disfruta el proceso de conocer gente nueva.")
    }

    return {
        readinessScore,
        needsSupport,
        narrative,
        recommendations,
    }
}
