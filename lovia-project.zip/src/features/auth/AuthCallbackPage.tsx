import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../../lib/supabase'

export function AuthCallbackPage() {
  const navigate = useNavigate()

  useEffect(() => {
    const finish = async () => {
      // getSession() trigger the session persistence from url params implicitly
      await supabase.auth.getSession()
      // Redirigir al dashboard u otra ruta de inicio
      navigate('/dashboard', { replace: true })
    }

    finish()
  }, [navigate])

  return (
    <div className="flex h-screen items-center justify-center bg-zinc-950 text-white">
      <div className="flex flex-col items-center">
        <div className="mb-4 h-12 w-12 animate-spin rounded-full border-4 border-indigo-600 border-t-transparent"></div>
        <p className="text-lg font-medium text-zinc-300">Iniciando sesión segura...</p>
      </div>
    </div>
  )
}

export default AuthCallbackPage
