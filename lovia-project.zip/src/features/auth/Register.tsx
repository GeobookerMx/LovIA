import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuthStore } from '../../stores/authStore'
import { supabase } from '../../lib/supabase'
import { Mail, Lock, User, ArrowRight, Eye, EyeOff, AlertCircle, CheckCircle } from 'lucide-react'
import LegalModal from '../../components/ui/LegalModal'
import './Auth.css'

export default function Register() {
    const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [confirmPassword, setConfirmPassword] = useState('')
    const [showPassword, setShowPassword] = useState(false)
    const [error, setError] = useState<string | null>(null)
    const [success, setSuccess] = useState(false)
    const [showLegal, setShowLegal] = useState(false)
    const [legalAccepted, setLegalAccepted] = useState(false)
    const { signUp, loading } = useAuthStore()
    const navigate = useNavigate()

    const passwordChecks = {
        length: password.length >= 8,
        upper: /[A-Z]/.test(password),
        number: /[0-9]/.test(password),
        match: password === confirmPassword && confirmPassword.length > 0,
    }

    const allValid = Object.values(passwordChecks).every(Boolean) && legalAccepted && name.length >= 2

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        setError(null)

        if (!allValid) {
            if (!legalAccepted) setError('Debes aceptar los términos y condiciones')
            else if (name.length < 2) setError('El nombre debe tener al menos 2 caracteres')
            else if (!passwordChecks.length) setError('La contraseña debe tener al menos 8 caracteres')
            else if (!passwordChecks.upper) setError('La contraseña necesita al menos una mayúscula')
            else if (!passwordChecks.number) setError('La contraseña necesita al menos un número')
            else if (!passwordChecks.match) setError('Las contraseñas no coinciden')
            else setError('Por favor completa todos los campos correctamente')
            return
        }

        const result = await signUp(email, password, name)
        if (result.error) {
            // Translate common Supabase errors to Spanish
            if (result.error.includes('already registered')) {
                setError('Este email ya está registrado. ¿Quieres iniciar sesión?')
            } else if (result.error.includes('invalid')) {
                setError('Email o contraseña no válidos. La contraseña necesita 8+ caracteres, 1 mayúscula y 1 número.')
            } else if (result.error.includes('weak')) {
                setError('Contraseña demasiado débil. Usa 8+ caracteres con mayúscula y número.')
            } else {
                setError(result.error)
            }
        } else {
            // With email confirmation disabled, session is auto-created
            // Navigate directly to home
            setSuccess(true)
            setTimeout(() => navigate('/home'), 1500)
        }
    }

    const handleOAuthLogin = async (provider: 'google' | 'apple') => {
        const { error } = await supabase.auth.signInWithOAuth({
            provider,
            options: {
                redirectTo: `${window.location.origin}/onboarding`
            }
        })
        if (error) setError(error.message)
    }

    if (success) {
        return (
            <div className="auth-page">
                <div className="auth-page__glow auth-page__glow--1" />
                <div className="auth-card glass-strong animate-scale-in" style={{ textAlign: 'center' }}>
                    <div className="auth-card__success-icon animate-heartbeat">
                        <CheckCircle size={48} color="var(--success)" />
                    </div>
                    <h2>¡Cuenta creada!</h2>
                    <p style={{ color: 'var(--text-secondary)', marginTop: 'var(--space-3)' }}>
                        ¡Bienvenido/a a LovIA! Entrando a tu cuenta...
                    </p>
                </div>
            </div>
        )
    }

    return (
        <div className="auth-page">
            <div className="auth-page__glow auth-page__glow--1" />
            <div className="auth-page__glow auth-page__glow--2" />

            <div className="auth-card glass-strong animate-scale-in">
                <div className="auth-card__header">
                    <h1>Lov<span className="text-gradient">IA!</span></h1>
                    <p>Crea tu cuenta</p>
                </div>

                <form onSubmit={handleSubmit} className="auth-card__form">
                    {error && (
                        <div className="auth-card__error animate-fade-in">
                            <AlertCircle size={16} />
                            <span>{error}</span>
                        </div>
                    )}

                    <div className="auth-card__field">
                        <label htmlFor="name">Nombre</label>
                        <div className="auth-card__input-wrap">
                            <User size={18} className="auth-card__input-icon" />
                            <input
                                id="name"
                                type="text"
                                placeholder="Tu nombre"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                required
                                minLength={2}
                                autoComplete="name"
                            />
                        </div>
                    </div>

                    <div className="auth-card__field">
                        <label htmlFor="reg-email">Email</label>
                        <div className="auth-card__input-wrap">
                            <Mail size={18} className="auth-card__input-icon" />
                            <input
                                id="reg-email"
                                type="email"
                                placeholder="tu@email.com"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                                autoComplete="email"
                            />
                        </div>
                    </div>

                    <div className="auth-card__field">
                        <label htmlFor="reg-password">Contraseña</label>
                        <div className="auth-card__input-wrap">
                            <Lock size={18} className="auth-card__input-icon" />
                            <input
                                id="reg-password"
                                type={showPassword ? 'text' : 'password'}
                                placeholder="Mínimo 8 caracteres"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                                minLength={8}
                                autoComplete="new-password"
                            />
                            <button
                                type="button"
                                className="auth-card__toggle-pw"
                                onClick={() => setShowPassword(!showPassword)}
                                aria-label={showPassword ? 'Ocultar' : 'Mostrar'}
                            >
                                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                            </button>
                        </div>

                        <div className="auth-card__pw-checks">
                            <PwCheck ok={passwordChecks.length} label="8+ caracteres" />
                            <PwCheck ok={passwordChecks.upper} label="Una mayúscula" />
                            <PwCheck ok={passwordChecks.number} label="Un número" />
                        </div>
                    </div>

                    <div className="auth-card__field">
                        <label htmlFor="confirm-password">Confirmar contraseña</label>
                        <div className="auth-card__input-wrap">
                            <Lock size={18} className="auth-card__input-icon" />
                            <input
                                id="confirm-password"
                                type={showPassword ? 'text' : 'password'}
                                placeholder="Repite tu contraseña"
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                                required
                                autoComplete="new-password"
                            />
                        </div>
                        {confirmPassword && (
                            <PwCheck ok={passwordChecks.match} label={passwordChecks.match ? 'Contraseñas coinciden' : 'No coinciden'} />
                        )}
                    </div>

                    {/* Legal consent */}
                    <div className="auth-card__legal">
                        <label className="auth-card__checkbox-label">
                            <input
                                type="checkbox"
                                checked={legalAccepted}
                                onChange={(e) => {
                                    if (e.target.checked) {
                                        setShowLegal(true)
                                    } else {
                                        setLegalAccepted(false)
                                    }
                                }}
                            />
                            <span>
                                Acepto el{' '}
                                <button type="button" className="auth-card__link" onClick={() => setShowLegal(true)}>
                                    Aviso de Privacidad
                                </button>{' '}
                                y los{' '}
                                <button type="button" className="auth-card__link" onClick={() => setShowLegal(true)}>
                                    Términos y Condiciones
                                </button>
                            </span>
                        </label>
                    </div>

                    <button type="submit" className="auth-card__submit" disabled={loading || !allValid}>
                        {loading ? (
                            <span className="auth-card__spinner" />
                        ) : (
                            <>
                                Crear cuenta <ArrowRight size={18} />
                            </>
                        )}
                    </button>
                </form>

                <div className="auth-divider">
                    <span>O regístrate con</span>
                </div>

                <div className="auth-social">
                    <button className="btn-social google" onClick={() => handleOAuthLogin('google')}>
                        <img src="https://fonts.gstatic.com/s/i/productlogos/googleg/v6/24px.svg" alt="Google" width="20" />
                        Google
                    </button>
                    <button className="btn-social apple" onClick={() => handleOAuthLogin('apple')}>
                        <svg viewBox="0 0 384 512" width="18" fill="currentColor"><path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z"/></svg>
                        Apple
                    </button>
                </div>

                <p className="auth-card__footer">
                    ¿Ya tienes cuenta? <Link to="/login">Iniciar sesión</Link>
                </p>
            </div>

            {showLegal && (
                <LegalModal
                    onAccept={() => {
                        setLegalAccepted(true)
                        setShowLegal(false)
                    }}
                    onClose={() => setShowLegal(false)}
                />
            )}
        </div>
    )
}

function PwCheck({ ok, label }: { ok: boolean; label: string }) {
    return (
        <span className={`auth-card__pw-check ${ok ? 'auth-card__pw-check--ok' : ''}`}>
            {ok ? <CheckCircle size={12} /> : <span className="auth-card__pw-dot" />}
            {label}
        </span>
    )
}
